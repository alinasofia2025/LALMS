<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Appointment> $appointments
 */
use Cake\Routing\Router;
echo $this->Html->css('select2/css/select2.css');
echo $this->Html->script('select2/js/select2.full.min.js');
echo $this->Html->css('jquery.datetimepicker.min.css');
echo $this->Html->script('jquery.datetimepicker.full.js');
echo $this->Html->script('https://cdn.jsdelivr.net/npm/apexcharts');
echo $this->Html->script('https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js');
$c_name = $this->request->getParam('controller');
echo $this->Html->script('bootstrapModal', ['block' => 'scriptBottom']);
?>

<style>
/* ===== TEMA TEAL + GLASS + PATTERN (sama seperti sebelumnya) ===== */
:root {
    --teal-primary: #00897b;
    --teal-light: #26a69a;
    --teal-lighter: #4dd0e1;
    --teal-dark: #00695c;
    --teal-bg: #e0f2f1;
    --teal-gradient: linear-gradient(135deg, #00897b, #26a69a, #4dd0e1);
    --glass-bg: rgba(255, 255, 255, 0.65);
    --glass-border: rgba(255, 255, 255, 0.35);
    --glass-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
}

body {
    background: #f2f7f7;
    background-image: 
        radial-gradient(circle at 20px 20px, rgba(0,137,123,0.07) 2px, transparent 2px),
        radial-gradient(circle at 60px 60px, rgba(0,137,123,0.04) 3px, transparent 3px);
    background-size: 40px 40px, 80px 80px;
    min-height: 100vh;
    position: relative;
}
body::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(145deg, rgba(0,137,123,0.02) 0%, transparent 50%, rgba(0,137,123,0.02) 100%);
    pointer-events: none;
    z-index: 0;
}
.page-content {
    position: relative;
    z-index: 1;
}

.page_title {
    color: #00897b;
    font-weight: 700;
    letter-spacing: -0.5px;
}
.sub_title {
    color: #4a6a6a;
    font-weight: 400;
}
.line {
    border-bottom: 2px solid #00897b;
    opacity: 0.25;
    margin-top: 8px;
}

/* ===== KAD STATISTIK (seperti dalam gambar) ===== */
.dashboard-card {
    background: var(--glass-bg);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid var(--glass-border);
    border-radius: 20px;
    padding: 20px 20px 15px;
    box-shadow: var(--glass-shadow);
    transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    text-align: center;
}
.dashboard-card:hover {
    transform: translateY(-6px);
    box-shadow: 0 16px 48px rgba(0, 137, 123, 0.12);
    background: rgba(255, 255, 255, 0.8);
}
.dashboard-card .stat-number {
    font-size: 2.8rem;
    font-weight: 700;
    color: #00897b;
    line-height: 1.2;
}
.dashboard-card .stat-label {
    font-size: 1rem;
    font-weight: 500;
    color: #4a6a6a;
    margin: 5px 0 12px;
}
.dashboard-card .btn-open {
    border-radius: 30px;
    padding: 6px 18px;
    font-size: 0.85rem;
    font-weight: 500;
    background: rgba(0, 137, 123, 0.08);
    color: #00897b;
    border: 1px solid rgba(0, 137, 123, 0.15);
    transition: 0.3s;
    text-decoration: none;
    display: inline-block;
}
.dashboard-card .btn-open:hover {
    background: #00897b;
    color: #fff;
    border-color: #00897b;
    box-shadow: 0 4px 12px rgba(0, 137, 123, 0.25);
    transform: scale(1.02);
}

/* ===== KAD SENARAI TERBARU (glass) ===== */
.latest-card {
    background: var(--glass-bg);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid var(--glass-border);
    border-radius: 20px;
    padding: 0;
    overflow: hidden;
    box-shadow: var(--glass-shadow);
}
.latest-card .card-header {
    background: linear-gradient(135deg, #00897b, #26a69a);
    padding: 16px 24px;
    color: white;
    font-weight: 600;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.latest-card .card-header i {
    margin-right: 10px;
}
.latest-table {
    margin: 0;
    border-collapse: separate;
    border-spacing: 0;
}
.latest-table thead th {
    background: rgba(0, 137, 123, 0.06);
    color: #00695c;
    font-weight: 600;
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    padding: 12px 16px;
    border-bottom: 2px solid #00897b;
}
.latest-table tbody tr {
    transition: 0.2s;
}
.latest-table tbody tr:hover {
    background: rgba(0, 137, 123, 0.04);
}
.latest-table tbody td {
    padding: 12px 16px;
    vertical-align: middle;
    border-bottom: 1px solid rgba(0, 137, 123, 0.06);
    color: #2d3e3e;
}
.latest-table tbody tr:last-child td {
    border-bottom: none;
}

.btn-action-sm {
    border-radius: 8px;
    padding: 4px 12px;
    font-size: 0.75rem;
    font-weight: 500;
    transition: 0.25s;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    text-decoration: none;
    border: 1px solid transparent;
}
.btn-action-sm:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    text-decoration: none;
}
.btn-view-sm {
    background: rgba(0, 137, 123, 0.1);
    color: #00897b;
    border-color: rgba(0, 137, 123, 0.2);
}
.btn-view-sm:hover {
    background: #00897b;
    color: #fff;
    border-color: #00897b;
}

.badge-status {
    padding: 4px 12px;
    border-radius: 30px;
    font-size: 0.75rem;
    font-weight: 500;
}

@media (max-width: 768px) {
    .dashboard-card .stat-number {
        font-size: 2rem;
    }
}
</style>

<div class="page-content">
    <!-- ===== HEADER ===== -->
    <div class="row text-body-secondary">
        <div class="col-10">
            <h1 class="my-0 page_title"><?php echo $title; ?></h1>
            <h6 class="sub_title text-body-secondary"><?php echo $system_name; ?></h6>
        </div>
        <div class="col-2 text-end">
            <div class="dropdown mx-3 mt-2">
                <button class="btn p-0 border-0" type="button" id="orederStatistics" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa-solid fa-bars text-teal" style="color:#00897b;font-size:1.5rem;"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
                    <li><?= $this->Html->link(__('<i class="fa-solid fa-plus"></i> New Appointment'), ['action' => 'add'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
                </div>
            </div>
        </div>
    </div>
    <div class="line mb-4"></div>

    <!-- ===== KAD STATISTIK (6 modul) ===== -->
    <div class="row g-3 mb-4">
        <!-- Faculty -->
        <div class="col-md-4 col-lg-2">
            <div class="dashboard-card">
                <div class="stat-number"><?= $total_faculties ?? 0 ?></div>
                <div class="stat-label">Faculty</div>
                <?= $this->Html->link('Open Module →', ['controller' => 'Faculties', 'action' => 'index'], ['class' => 'btn-open']) ?>
            </div>
        </div>
        <!-- Program -->
        <div class="col-md-4 col-lg-2">
            <div class="dashboard-card">
                <div class="stat-number"><?= $total_programs ?? 0 ?></div>
                <div class="stat-label">Program</div>
                <?= $this->Html->link('Open Module →', ['controller' => 'Programs', 'action' => 'index'], ['class' => 'btn-open']) ?>
            </div>
        </div>
        <!-- Project -->
        <div class="col-md-4 col-lg-2">
            <div class="dashboard-card">
                <div class="stat-number"><?= $total_projects ?? 0 ?></div>
                <div class="stat-label">Project</div>
                <?= $this->Html->link('Open Module →', ['controller' => 'Projects', 'action' => 'index'], ['class' => 'btn-open']) ?>
            </div>
        </div>
        <!-- Lecturer -->
        <div class="col-md-4 col-lg-2">
            <div class="dashboard-card">
                <div class="stat-number"><?= $total_lecturers ?? 0 ?></div>
                <div class="stat-label">Lecturer</div>
                <?= $this->Html->link('Open Module →', ['controller' => 'Lecturers', 'action' => 'index'], ['class' => 'btn-open']) ?>
            </div>
        </div>
        <!-- Subject -->
        <div class="col-md-4 col-lg-2">
            <div class="dashboard-card">
                <div class="stat-number"><?= $total_subjects ?? 0 ?></div>
                <div class="stat-label">Subject</div>
                <?= $this->Html->link('Open Module →', ['controller' => 'Subjects', 'action' => 'index'], ['class' => 'btn-open']) ?>
            </div>
        </div>
        <!-- Appointment Letter -->
        <div class="col-md-4 col-lg-2">
            <div class="dashboard-card">
                <div class="stat-number"><?= $total_appointments ?? 0 ?></div>
                <div class="stat-label">Appointment Letter</div>
                <?= $this->Html->link('Open Module →', ['action' => 'index'], ['class' => 'btn-open']) ?>
            </div>
        </div>
    </div>

    <!-- ===== SENARAI "Latest Appointment Letters" ===== -->
    <div class="latest-card">
        <div class="card-header">
            <span><i class="fa-solid fa-clock"></i> Latest Appointment Letters</span>
            <span class="badge bg-light text-teal" style="color:#00897b;background:rgba(255,255,255,0.3)!important;">
                <?= $appointments->count() ?> records
            </span>
        </div>
        <div class="table-responsive">
            <table class="table latest-table mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Lecturer</th>
                        <th>Faculty</th>
                        <th>Ref No</th>
                        <th>Title</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $counter = 1;
                    foreach ($appointments as $appointment): 
                    ?>
                    <tr>
                        <td><?= $counter++ ?></td>
                        <td><?= $appointment->hasValue('lecturer') ? $this->Html->link($appointment->lecturer->name, ['controller' => 'Lecturers', 'action' => 'view', $appointment->lecturer->lecturer_id], ['class' => 'text-teal', 'style' => 'color:#00897b;text-decoration:none;font-weight:500;']) : '-' ?></td>
                        <td><?= $appointment->hasValue('faculty') ? $this->Html->link($appointment->faculty->code, ['controller' => 'Faculties', 'action' => 'view', $appointment->faculty->faculties_id], ['class' => 'text-teal', 'style' => 'color:#00897b;text-decoration:none;']) : '-' ?></td>
                        <td><span class="fw-semibold"><?= h($appointment->letter_ref_no) ?></span></td>
                        <td><?= h($appointment->appointment_title) ?></td>
                        <td><?= h($appointment->appointment_date) ?></td>
                        <td>
                            <?php if ($appointment->status == 1): ?>
                                <span class="badge-status bg-success bg-opacity-10 text-success">Approved</span>
                            <?php elseif ($appointment->status == 2): ?>
                                <span class="badge-status bg-secondary bg-opacity-10 text-secondary">Archived</span>
                            <?php else: ?>
                                <span class="badge-status bg-warning bg-opacity-10 text-warning">Draft</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?= $this->Html->link(
                                '<i class="fa-solid fa-eye"></i> View',
                                ['action' => 'view', $appointment->appointments_id],
                                ['class' => 'btn-action-sm btn-view-sm', 'escape' => false, 'title' => 'View']
                            ) ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <!-- Optional: jika mahu pagination, letak di sini -->
        <?php if ($this->Paginator->hasPrev() || $this->Paginator->hasNext()): ?>
        <div class="d-flex justify-content-between align-items-center p-3" style="border-top:1px solid rgba(0,137,123,0.06); background:rgba(255,255,255,0.2); backdrop-filter:blur(4px);">
            <div><?= $this->Paginator->counter(__('Showing {{current}} of {{count}} records')) ?></div>
            <ul class="pagination pagination-sm mb-0">
                <?= $this->Paginator->first('<<') ?>
                <?= $this->Paginator->prev('<') ?>
                <?= $this->Paginator->numbers(['before' => '', 'after' => '']) ?>
                <?= $this->Paginator->next('>') ?>
                <?= $this->Paginator->last('>>') ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal Confirm Delete (sama seperti sebelumnya) -->
<div class="modal" id="bootstrapModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="background: rgba(255,255,255,0.9); backdrop-filter: blur(16px); border: 1px solid rgba(255,255,255,0.3);">
            <div class="modal-header" style="border-bottom:2px solid #00897b;">
                <h5 class="modal-title" style="color:#00897b;"><i class="fa-regular fa-circle-exclamation me-2"></i>Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center py-4">
                <i class="fa-regular fa-circle-xmark fa-5x text-danger mb-3"></i>
                <p id="confirmMessage" class="fs-5"></p>
            </div>
            <div class="modal-footer" style="border-top:1px solid rgba(0,137,123,0.1);">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-teal" id="ok">Yes, Delete</button>
            </div>
        </div>
    </div>
</div>