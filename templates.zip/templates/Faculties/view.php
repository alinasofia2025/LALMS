<?php $this->assign('title', $title); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h1 class="h3 mb-0"><?= h($title) ?></h1>
        <div class="text-muted">Record details</div>
    </div>
    <div class="d-flex gap-2">
        <?= $this->Html->link(__('<i class="fa-solid fa-arrow-left"></i> Back'), ['action' => 'index'], ['class' => 'btn btn-outline-secondary', 'escapeTitle' => false]) ?>
        <?= $this->Html->link(__('<i class="fa-solid fa-pen"></i> Edit'), ['action' => 'edit', $faculty->faculties_id], ['class' => 'btn btn-warning', 'escapeTitle' => false]) ?>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body table-responsive">
        <table class="table table-bordered mb-0">
            <tbody>
                    <tr><th style="width:260px">ID</th><td><?= h($faculty->faculties_id) ?></td></tr>
                    <tr><th style="width:260px">Name</th><td><?= h($faculty->name) ?></td></tr>
                    <tr><th style="width:260px">Code</th><td><?= h($faculty->code) ?></td></tr>
                    <tr><th style="width:260px">Status</th><td><?= $faculty->status == 1 ? "Active" : ($faculty->status == 2 ? "Archived" : "Disabled") ?></td></tr>
                    <tr><th style="width:260px">Created</th><td><?= h($faculty->created) ?></td></tr>
                    <tr><th style="width:260px">Modified</th><td><?= h($faculty->modified) ?></td></tr>
            </tbody>
        </table>
    </div>
</div>
