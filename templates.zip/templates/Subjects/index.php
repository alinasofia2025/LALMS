<?php $this->assign('title', $title); ?>

<style>
/* ============================================================
   TEMA TEAL GLASS UNTUK SUBJECTS INDEX
   ============================================================ */

:root {
    --teal-primary: #00897b;
    --teal-light: #26a69a;
    --teal-lighter: #4dd0e1;
    --teal-dark: #00695c;
    --glass-bg: rgba(255, 255, 255, 0.7);
    --glass-border: rgba(0, 137, 123, 0.12);
    --glass-shadow: 0 8px 32px rgba(0, 137, 123, 0.08);
    --text-primary: #1a2a3a;
    --text-muted: #4a6a6a;
    --card-bg: #ffffff;
    --hover-bg: rgba(0, 137, 123, 0.04);
    --table-header-bg: #f0f7f6;
    --table-header-color: #00695c;
    --search-box-bg: #ffffff;
    --pagination-bg: #ffffff;
}

[data-bs-theme="dark"] {
    --glass-bg: rgba(10, 30, 34, 0.8);
    --glass-border: rgba(77, 208, 225, 0.15);
    --glass-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
    --text-primary: #e0f7fa;
    --text-muted: #a0c4c8;
    --card-bg: rgba(10, 30, 34, 0.75);
    --hover-bg: rgba(77, 208, 225, 0.08);
    --table-header-bg: rgba(0, 60, 55, 0.85);
    --table-header-color: #e0f7fa;
    --search-box-bg: rgba(0, 0, 0, 0.3);
    --pagination-bg: rgba(0, 0, 0, 0.2);
}

/* ----- HEADER ----- */
.page-header h1 {
    color: var(--teal-primary);
    font-weight: 700;
}
[data-bs-theme="dark"] .page-header h1 {
    color: var(--teal-lighter);
}

/* ----- STAT CARDS (Glass) ----- */
.stat-card-teal {
    background: var(--glass-bg);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid var(--glass-border);
    border-radius: 16px;
    padding: 20px 25px;
    box-shadow: var(--glass-shadow);
    border-left: 5px solid var(--teal-primary);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    color: var(--text-primary);
}
.stat-card-teal:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 40px rgba(0, 137, 123, 0.15);
}
.stat-card-teal .stat-number {
    font-size: 2rem;
    font-weight: 700;
    color: var(--teal-primary);
    margin: 0;
}
[data-bs-theme="dark"] .stat-card-teal .stat-number {
    color: var(--teal-lighter);
}
.stat-card-teal .stat-label {
    color: var(--text-muted);
    font-weight: 500;
    margin: 5px 0 0;
    font-size: 0.9rem;
}
.stat-card-teal .stat-icon {
    position: absolute;
    right: 20px;
    top: 20px;
    font-size: 2.5rem;
    opacity: 0.12;
    color: var(--teal-primary);
}
[data-bs-theme="dark"] .stat-card-teal .stat-icon {
    opacity: 0.2;
}

/* ----- TABLE WRAPPER (Glass) ----- */
.table-card-wrapper {
    background: var(--glass-bg);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid var(--glass-border);
    border-radius: 16px;
    overflow: hidden;
    box-shadow: var(--glass-shadow);
    transition: all 0.3s ease;
}
.table-card-wrapper:hover {
    box-shadow: 0 12px 40px rgba(0, 137, 123, 0.12);
}

/* Header table – gradient teal */
.table-card-wrapper .table-header {
    background: linear-gradient(135deg, var(--teal-primary), var(--teal-light));
    padding: 16px 20px;
    color: white;
    font-weight: 600;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.table-card-wrapper .table-header i {
    margin-right: 10px;
}
.table-card-wrapper .table-header .badge-teal-count {
    background: rgba(255,255,255,0.2);
    color: #fff;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
}

/* ----- TABLE STYLE ----- */
.table-teal {
    margin: 0;
    border-collapse: separate;
    border-spacing: 0;
    color: var(--text-primary);
}
.table-teal thead th {
    background: var(--table-header-bg);
    color: var(--table-header-color);
    font-weight: 600;
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    padding: 12px 16px;
    border-bottom: 2px solid var(--teal-primary);
}
[data-bs-theme="dark"] .table-teal thead th {
    border-bottom-color: var(--teal-lighter);
}
.table-teal tbody tr {
    transition: all 0.2s ease;
    border-left: 3px solid transparent;
}
.table-teal tbody tr:hover {
    background: var(--hover-bg);
    border-left-color: var(--teal-primary);
    transform: scale(1.003);
    box-shadow: 0 2px 10px rgba(0, 137, 123, 0.06);
}
.table-teal tbody td {
    padding: 12px 16px;
    vertical-align: middle;
    border-bottom: 1px solid var(--glass-border);
}
.table-teal tbody tr:last-child td {
    border-bottom: none;
}

/* ----- BUTANG CANTIK ----- */
.btn-action {
    border-radius: 8px;
    padding: 5px 12px;
    font-size: 0.8rem;
    font-weight: 500;
    transition: all 0.25s ease;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}
.btn-action i {
    font-size: 0.9rem;
}
.btn-action:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

/* View button */
.btn-view {
    background: rgba(0, 137, 123, 0.1);
    color: var(--teal-primary);
    border: 1px solid rgba(0, 137, 123, 0.2);
}
.btn-view:hover {
    background: var(--teal-primary);
    color: #fff;
    box-shadow: 0 4px 12px rgba(0, 137, 123, 0.3);
}

/* Edit button */
.btn-edit {
    background: rgba(255, 179, 0, 0.1);
    color: #f9a825;
    border: 1px solid rgba(255, 179, 0, 0.2);
}
.btn-edit:hover {
    background: #f9a825;
    color: #fff;
    box-shadow: 0 4px 12px rgba(255, 179, 0, 0.3);
}

/* Delete button */
.btn-delete {
    background: rgba(220, 53, 69, 0.1);
    color: #dc3545;
    border: 1px solid rgba(220, 53, 69, 0.2);
}
.btn-delete:hover {
    background: #dc3545;
    color: #fff;
    box-shadow: 0 4px 12px rgba(220, 53, 69, 0.3);
}

/* Add Subject button */
.btn-teal {
    background: linear-gradient(135deg, var(--teal-primary), var(--teal-light));
    border: none;
    color: #fff;
    border-radius: 10px;
    padding: 10px 20px;
    font-weight: 600;
    transition: all 0.3s ease;
}
.btn-teal:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(0, 137, 123, 0.35);
    color: #fff;
}

/* Search button */
.btn-search {
    background: linear-gradient(135deg, var(--teal-primary), var(--teal-light));
    border: none;
    color: #fff;
    border-radius: 10px;
    padding: 10px 20px;
    font-weight: 600;
    transition: all 0.3s ease;
}
.btn-search:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0, 137, 123, 0.3);
    color: #fff;
}

/* Search box (glass) */
.search-box-teal {
    border-radius: 12px;
    border: 1px solid var(--glass-border);
    background: var(--search-box-bg);
    backdrop-filter: blur(4px);
    -webkit-backdrop-filter: blur(4px);
    transition: 0.3s;
    padding: 10px 16px;
    color: var(--text-primary);
}
.search-box-teal:focus {
    border-color: var(--teal-primary);
    box-shadow: 0 0 0 3px rgba(0, 137, 123, 0.1);
}
[data-bs-theme="dark"] .search-box-teal {
    color: #e0f7fa;
}
[data-bs-theme="dark"] .search-box-teal::placeholder {
    color: #a0c4c8;
}

/* Pagination (glass) */
.pagination {
    --bs-pagination-bg: var(--pagination-bg);
    --bs-pagination-border-color: var(--glass-border);
    --bs-pagination-hover-bg: var(--hover-bg);
    --bs-pagination-hover-color: var(--teal-primary);
    --bs-pagination-active-bg: var(--teal-primary);
    --bs-pagination-active-border-color: var(--teal-primary);
    --bs-pagination-color: var(--teal-primary);
}
.pagination .page-link {
    background: var(--pagination-bg);
    backdrop-filter: blur(4px);
    -webkit-backdrop-filter: blur(4px);
    border: 1px solid var(--glass-border);
    color: var(--teal-primary);
}
[data-bs-theme="dark"] .pagination .page-link {
    color: var(--teal-lighter);
}
.pagination .page-item.active .page-link {
    background: var(--teal-primary);
    border-color: var(--teal-primary);
    color: #fff;
}
.pagination .page-link:hover {
    background: var(--hover-bg);
    color: var(--teal-dark);
}
[data-bs-theme="dark"] .pagination .page-link:hover {
    color: #fff;
}
</style>

<!-- ===== HEADER ===== -->
<div class="d-flex justify-content-between align-items-center mb-3 page-header">
    <div>
        <h1 class="h3 mb-0"><?= h($title) ?></h1>
        <div class="text-muted" style="color:var(--text-muted) !important;">Manage subject records</div>
    </div>
    <?= $this->Html->link(
        __('<i class="fa-solid fa-plus me-1"></i> Add Subject'),
        ['action' => 'add'],
        ['class' => 'btn btn-teal', 'escapeTitle' => false]
    ) ?>
</div>

<!-- ===== STAT CARDS ===== -->
<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="stat-card-teal">
            <!-- Ikon Total Records TELAH DITUKAR kepada fa-cubes -->
            <i class="fa-regular fa-cubes stat-icon"></i>
            <div class="stat-number"><?= $total_records ?></div>
            <div class="stat-label">Total Records</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card-teal" style="border-left-color:var(--teal-light);">
            <i class="fa-regular fa-circle-check stat-icon" style="color:var(--teal-light);"></i>
            <div class="stat-number"><?= $active_records ?></div>
            <div class="stat-label">Active</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card-teal" style="border-left-color:#78909c;">
            <i class="fa-regular fa-circle-xmark stat-icon" style="color:#78909c;"></i>
            <div class="stat-number"><?= $disabled_records ?></div>
            <div class="stat-label">Disabled</div>
        </div>
    </div>
</div>

<!-- ===== TABLE CARD ===== -->
<div class="table-card-wrapper">
    <div class="table-header">
        <span><i class="fa-solid fa-book"></i> Subject List</span>
        <span class="badge-teal-count"><?= $total_records ?> records</span>
    </div>

    <div class="p-3">
        <!-- Search Form -->
        <?= $this->Form->create(null, ['type' => 'get', 'class' => 'row g-2 mb-3']) ?>
        <div class="col-md-10">
            <?= $this->Form->control('search', [
                'label' => false,
                'value' => $search ?? '',
                'class' => 'form-control search-box-teal',
                'placeholder' => 'Search by code, name, lecturer...'
            ]) ?>
        </div>
        <div class="col-md-2 d-grid">
            <button class="btn btn-search" type="submit">
                <i class="fa-solid fa-magnifying-glass me-1"></i> Search
            </button>
        </div>
        <?= $this->Form->end() ?>

        <!-- Table -->
        <div class="table-responsive">
            <table class="table table-teal align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Credit Hours</th>
                        <th>Lecturer</th>
                        <th>Status</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($subjects as $item): ?>
                    <tr>
                        <td><span class="fw-semibold"><?= h($item->subjects_id) ?></span></td>
                        <td><?= h($item->code) ?></td>
                        <td><?= h($item->name) ?></td>
                        <td><?= h($item->credit_hours) ?></td>
                        <td><?= h($item->lecturer->name ?? "-") ?></td>
                        <!-- ===== STATUS SEBAGAI TEKS SAHAJA ===== -->
                        <td>
                            <?php if ($item->status == 1): ?>
                                Active
                            <?php elseif ($item->status == 2): ?>
                                Archived
                            <?php else: ?>
                                Disabled
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <div class="d-flex gap-1 justify-content-center">
                                <?= $this->Html->link(
                                    __('<i class="fa-solid fa-eye"></i> View'),
                                    ['action' => 'view', $item->subjects_id],
                                    ['class' => 'btn-action btn-view', 'escapeTitle' => false, 'title' => 'View']
                                ) ?>
                                <?= $this->Html->link(
                                    __('<i class="fa-solid fa-pen"></i> Edit'),
                                    ['action' => 'edit', $item->subjects_id],
                                    ['class' => 'btn-action btn-edit', 'escapeTitle' => false, 'title' => 'Edit']
                                ) ?>
                                <?= $this->Form->postLink(
                                    __('<i class="fa-solid fa-trash"></i> Delete'),
                                    ['action' => 'delete', $item->subjects_id],
                                    [
                                        'confirm' => __('Are you sure you want to delete # {0}?', $item->subjects_id),
                                        'class' => 'btn-action btn-delete',
                                        'escapeTitle' => false,
                                        'title' => 'Delete'
                                    ]
                                ) ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="d-flex flex-wrap justify-content-between align-items-center pt-3" style="border-top:1px solid var(--glass-border);">
            <div class="text-muted small" style="color:var(--text-muted) !important;">
                <?= $this->Paginator->counter(__('Page {page} of {pages}, showing {current} record(s) out of {count} total')) ?>
            </div>
            <ul class="pagination pagination-sm mb-0">
                <?= $this->Paginator->first('<<') ?>
                <?= $this->Paginator->prev('<') ?>
                <?= $this->Paginator->numbers() ?>
                <?= $this->Paginator->next('>') ?>
                <?= $this->Paginator->last('>>') ?>
            </ul>
        </div>
    </div>
</div>