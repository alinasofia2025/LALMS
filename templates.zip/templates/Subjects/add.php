<?php $this->assign('title', $title); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h1 class="h3 mb-0"><?= h($title) ?></h1>
        <div class="text-muted">Fill in the form below</div>
    </div>
    <?= $this->Html->link(__('<i class="fa-solid fa-arrow-left"></i> Back'), ['action' => 'index'], ['class' => 'btn btn-outline-secondary', 'escapeTitle' => false]) ?>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <?= $this->Form->create($subject) ?>
        <div class="row g-3">
            <div class="col-md-6">
                <?= $this->Form->control('lecturer_id', ['class' => 'form-select', 'options' => $lecturers, 'empty' => 'Select Lecturer']) ?>
            </div>
            <div class="col-md-3">
                <?= $this->Form->control('code', ['class' => 'form-control']) ?>
            </div>
            <div class="col-md-3">
                <?= $this->Form->control('credit_hours', ['class' => 'form-control']) ?>
            </div>
            <div class="col-md-8">
                <?= $this->Form->control('name', ['class' => 'form-control']) ?>
            </div>
            <div class="col-md-4">
                <?= $this->Form->control('status', ['class' => 'form-select', 'options' => [1 => 'Active', 0 => 'Disabled', 2 => 'Archived']]) ?>
            </div>
            <div class="col-12 d-flex gap-2">
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
                <?= $this->Html->link(__('Cancel'), ['action' => 'index'], ['class' => 'btn btn-light']) ?>
            </div>
        </div>
        <?= $this->Form->end() ?>
    </div>
</div>
