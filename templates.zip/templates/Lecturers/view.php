

<?php $this->assign('title', $title); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h1 class="h3 mb-0"><?= h($title) ?></h1>
        <div class="text-muted">Record details</div>
    </div>
    <div class="d-flex gap-2">
        <?= $this->Html->link(__('<i class="fa-solid fa-arrow-left"></i> Back'), ['action' => 'index'], ['class' => 'btn btn-outline-secondary', 'escapeTitle' => false]) ?>
        <?= $this->Html->link(__('<i class="fa-solid fa-pen"></i> Edit'), ['action' => 'edit', $lecturer->lecturer_id], ['class' => 'btn btn-warning', 'escapeTitle' => false]) ?>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body table-responsive">
        <table class="table table-bordered mb-0">
            <tbody>
                    <tr><th style="width:260px">ID</th><td><?= h($lecturer->lecturer_id) ?></td></tr>
                    <tr><th style="width:260px">Name</th><td><?= h($lecturer->name) ?></td></tr>
                    <tr><th style="width:260px">Email</th><td><?= h($lecturer->email) ?></td></tr>
                    <tr><th style="width:260px">Faculty</th><td><?= h($lecturer->faculty->name ?? "-") ?></td></tr>
                    <tr><th style="width:260px">Program</th><td><?= h($lecturer->program->name ?? "-") ?></td></tr>
                    <tr><th style="width:260px">Status</th><td><?= $lecturer->status == 1 ? "Active" : ($lecturer->status == 2 ? "Archived" : "Disabled") ?></td></tr>
                    <tr><th style="width:260px">Created</th><td><?= h($lecturer->created) ?></td></tr>
                    <tr><th style="width:260px">Modified</th><td><?= h($lecturer->modified) ?></td></tr>
            </tbody>
        </table>
    </div>
</div>
