<!-- ================================================================ -->
<!-- TOP BAR (NAVBAR) - FULL WIDTH, GLASS EFFECT, DI ATAS SIDEBAR    -->
<!-- ================================================================ -->

<style>
/* Top bar - full width, tanpa padding luar */
.bd-navbar {
    position: sticky !important;
    top: 0 !important;
    left: 0 !important;
    width: 100% !important;
    z-index: 1002 !important; /* di atas sidebar */
    background: rgba(11, 59, 74, 0.4) !important;
    backdrop-filter: blur(14px) !important;
    -webkit-backdrop-filter: blur(14px) !important;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1) !important;
    padding: 0 !important; /* TIADA padding luar - full width */
    margin: 0 !important;
    box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2) !important;
}
.bd-navbar .container-fluid {
    padding-left: 20px !important;
    padding-right: 20px !important;
    width: 100% !important;
    margin: 0 auto !important;
}
/* Butang toggle dalam top bar */
#sidebarToggleNav {
    background: rgba(255,255,255,0.08) !important;
    border: none !important;
    color: #e0f0f5 !important;
    font-size: 24px !important;
    padding: 6px 14px !important;
    border-radius: 14px !important;
    transition: background 0.2s, transform 0.2s;
    cursor: pointer;
}
#sidebarToggleNav:hover {
    background: rgba(255,255,255,0.2) !important;
    transform: scale(1.05);
}
@media (min-width: 769px) {
    #sidebarToggleNav {
        display: none !important;
    }
}
.bd-navbar .dropdown .btn,
.bd-navbar .btn {
    color: #c5dce5 !important;
    transition: color 0.2s;
}
.bd-navbar .dropdown .btn:hover,
.bd-navbar .btn:hover {
    color: #ffffff !important;
}
.top_menu_separator {
    display: inline-block;
    width: 1px;
    height: 24px;
    background: rgba(255,255,255,0.15);
    margin: 0 10px;
    vertical-align: middle;
}
.dropdown-menu {
    background: rgba(11, 59, 74, 0.8) !important;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 16px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
}
.dropdown-item {
    color: #d4eaf0 !important;
    border-radius: 10px;
}
.dropdown-item:hover {
    background: rgba(255,255,255,0.1) !important;
    color: #fff !important;
}
.dropdown-item.active {
    background: rgba(0, 137, 123, 0.3) !important;
}
@media (max-width: 768px) {
    .bd-navbar {
        background: rgba(11, 59, 74, 0.7) !important;
    }
    .bd-navbar .container-fluid {
        padding-left: 16px !important;
        padding-right: 16px !important;
    }
}
</style>

<div class="navbar navbar-expand-lg bd-navbar sticky-top pt-0">
    <div class="content-fluid" style="width:100%;">
        <nav class="navbar" style="width:100%; background: transparent !important; padding:0; margin:0;">
            <div class="container-fluid" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: nowrap;">
                <!-- Kiri: butang toggle + logo -->
                <div class="d-flex align-items-center gap-3">
                    <button type="button" id="sidebarToggleNav" class="btn btn-sm text-light border-0">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                    <span class="text-light fw-bold d-none d-sm-inline" style="font-size:1.1rem; opacity:0.9;">
                        <i class="fa-solid fa-graduation-cap me-2"></i><?php echo $system_abbr; ?>
                    </span>
                </div>

                <!-- SVG ICON (sama) -->
                <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
                    <symbol id="check2" viewBox="0 0 16 16">
                        <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z" />
                    </symbol>
                    <symbol id="circle-half" viewBox="0 0 16 16" fill="#000000">
                        <path d="M8 15A7 7 0 1 0 8 1v14zm0 1A8 8 0 1 1 8 0a8 8 0 0 1 0 16z" />
                    </symbol>
                    <symbol id="moon-stars-fill" viewBox="0 0 16 16" fill="#ffffff">
                        <path d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z" />
                        <path d="M10.794 3.148a.217.217 0 0 1 .412 0l.387 1.162c.173.518.579.924 1.097 1.097l1.162.387a.217.217 0 0 1 0 .412l-1.162.387a1.734 1.734 0 0 0-1.097 1.097l-.387 1.162a.217.217 0 0 1-.412 0l-.387-1.162A1.734 1.734 0 0 0 9.31 6.593l-1.162-.387a.217.217 0 0 1 0-.412l1.162-.387a1.734 1.734 0 0 0 1.097-1.097l.387-1.162zM13.863.099a.145.145 0 0 1 .274 0l.258.774c.115.346.386.617.732.732l.774.258a.145.145 0 0 1 0 .274l-.774.258a1.156 1.156 0 0 0-.732.732l-.258.774a.145.145 0 0 1-.274 0l-.258-.774a1.156 1.156 0 0 0-.732-.732l-.774-.258a.145.145 0 0 1 0-.274l.774-.258c.346-.115.617-.386.732-.732L13.863.1z" />
                    </symbol>
                    <symbol id="sun-fill" viewBox="0 0 16 16" fill="#000000">
                        <path d="M8 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z" />
                    </symbol>
                </svg>

                <!-- Kanan: dropdown tema, fullscreen, logout -->
                <div class="d-flex align-items-center gap-2">
                    <div class="dropdown">
                        <a class="btn dropdown-toggle btn-sm border-0 transparent" id="bd-theme" type="button" aria-expanded="false" data-bs-toggle="dropdown" aria-label="Toggle theme (auto)">
                            <svg class="bi my-1 theme-icon-active" width="1.2em" height="1.2em">
                                <use href="#circle-half"></use>
                            </svg>
                            <span class="visually-hidden" id="bd-theme-text">Toggle theme</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="bd-theme-text">
                            <li>
                                <button type="button" class="dropdown-item d-flex align-items-center" data-bs-theme-value="light" aria-pressed="false">
                                    <svg class="bi me-2 opacity-50 theme-icon" width="1em" height="1em">
                                        <use href="#sun-fill"></use>
                                    </svg>
                                    Light
                                    <svg class="bi ms-auto d-none" width="1em" height="1em">
                                        <use href="#check2"></use>
                                    </svg>
                                </button>
                            </li>
                            <li>
                                <button type="button" class="dropdown-item d-flex align-items-center" data-bs-theme-value="dark" aria-pressed="false">
                                    <svg class="bi me-2 opacity-50 theme-icon" width="1em" height="1em">
                                        <use href="#moon-stars-fill"></use>
                                    </svg>
                                    Dark
                                    <svg class="bi ms-auto d-none" width="1em" height="1em">
                                        <use href="#check2"></use>
                                    </svg>
                                </button>
                            </li>
                            <li>
                                <button type="button" class="dropdown-item d-flex align-items-center active" data-bs-theme-value="auto" aria-pressed="true">
                                    <svg class="bi me-2 opacity-50 theme-icon" width="1em" height="1em">
                                        <use href="#circle-half"></use>
                                    </svg>
                                    Auto
                                    <svg class="bi ms-auto d-none" width="1em" height="1em">
                                        <use href="#check2"></use>
                                    </svg>
                                </button>
                            </li>
                        </ul>
                    </div>

                    <span class="top_menu_separator"></span>
                    <a class="btn btn-sm border-0 transparent" data-bs-toggle="offcanvas" onclick="toggleFull()" role="button"><i class="fa-solid fa-expand"></i></a>

                    <?php if ($this->Identity->isLoggedIn()) { ?>
                        <span class="top_menu_separator"></span>
                        <a class="btn btn-sm border-0 transparent" data-bs-toggle="offcanvas" href="#offcanvasWithBothOptions" role="button" aria-controls="offcanvasWithBothOptions offcanvasRight"><i class="fa-solid fa-outdent"></i></a>
                        <span class="top_menu_separator"></span>
                        <?php echo $this->Html->link('<i class="fa-solid fa-arrow-right-from-bracket"></i>', ['controller' => 'Users', 'action' => 'logout', 'prefix' => false], ['class' => 'btn btn-sm border-0 transparent', 'escape' => false, 'alt' => 'Sign-out']); ?>
                    <?php } ?>
                </div>
            </div>
        </nav>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const btnNav = document.getElementById('sidebarToggleNav');
    if (btnNav) {
        btnNav.addEventListener('click', function(e) {
            e.preventDefault();
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            if (sidebar) {
                sidebar.classList.toggle('active');
                if (overlay) overlay.classList.toggle('active');
            }
        });
    }
});

function toggleFull() {
    if ((document.fullScreenElement && document.fullScreenElement !== null) ||
        (!document.mozFullScreen && !document.webkitIsFullScreen)) {
        if (document.documentElement.requestFullScreen) {
            document.documentElement.requestFullScreen();
        } else if (document.documentElement.mozRequestFullScreen) {
            document.documentElement.mozRequestFullScreen();
        } else if (document.documentElement.webkitRequestFullScreen) {
            document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
        }
    } else {
        if (document.cancelFullScreen) {
            document.cancelFullScreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitCancelFullScreen) {
            document.webkitCancelFullScreen();
        }
    }
}
</script>