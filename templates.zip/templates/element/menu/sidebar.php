<?php
$c_name = $this->request->getParam('controller');
$a_name = $this->request->getParam('action');
?>

<style>
/* ============================================================
   SIDEBAR MELEKAT DI KIRI (SEBATI DENGAN KANDUNGAN)
   ============================================================ */

/* --- Padding pada body untuk desktop (elakkan pertindihan) --- */
body {
    padding-left: 280px !important; /* lebar sidebar tepat */
    transition: padding-left 0.5s cubic-bezier(0.23, 1, 0.32, 1);
}
@media (max-width: 768px) {
    body {
        padding-left: 0 !important;
    }
}

/* --- Overlay untuk mobile --- */
#sidebarOverlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(4px);
    z-index: 999;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.4s ease, visibility 0.4s ease;
}
#sidebarOverlay.active {
    opacity: 1;
    visibility: visible;
}

/* --- Sidebar utama (melekat penuh di tepi kiri) --- */
#sidebar {
    position: fixed !important;
    top: 0 !important;          /* tiada jarak dari atas */
    left: 0 !important;         /* tiada jarak dari kiri */
    bottom: 0 !important;       /* tiada jarak dari bawah */
    width: 280px !important;
    max-width: 280px !important;
    min-width: 280px !important;
    background: rgba(11, 59, 74, 0.55) !important;
    backdrop-filter: blur(16px) !important;
    -webkit-backdrop-filter: blur(16px) !important;
    border-right: 1px solid rgba(255, 255, 255, 0.15) !important; /* garis pemisah halus di tepi kanan */
    border-radius: 0 !important; /* tiada sudut bulat – sebati */
    box-shadow: 2px 0 20px rgba(0, 0, 0, 0.2) !important; /* bayangan hanya ke kanan */
    color: #d4eaf0 !important;
    padding: 0 !important;
    z-index: 1000 !important;
    overflow-y: auto !important;
    transition: transform 0.5s cubic-bezier(0.23, 1, 0.32, 1), 
                opacity 0.5s ease !important;
    transform: translateX(0) !important;
    opacity: 1 !important;
    scrollbar-width: thin;
    scrollbar-color: rgba(255,255,255,0.2) transparent;
}
#sidebar::-webkit-scrollbar {
    width: 4px;
}
#sidebar::-webkit-scrollbar-thumb {
    background: rgba(255,255,255,0.25);
    border-radius: 10px;
}

/* --- Keadaan tertutup (mobile) --- */
@media (max-width: 768px) {
    #sidebar {
        transform: translateX(-120%) !important;
        opacity: 0 !important;
        left: 0 !important;
        top: 0 !important;
        bottom: 0 !important;
        width: 280px !important;
        max-width: 280px !important;
        border-radius: 0 !important;
        border-right: none !important;
    }
    #sidebar.active {
        transform: translateX(0) !important;
        opacity: 1 !important;
    }
}

/* --- Header sidebar --- */
.sidebar-header {
    padding: 22px 20px 18px !important;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
    display: flex;
    align-items: center;
    gap: 10px;
}
.sidebar-header b {
    color: #e0f7fa !important;
    text-shadow: 0 2px 8px rgba(0,0,0,0.4) !important;
    font-size: 1.1rem;
    letter-spacing: 0.5px;
}
.sidebar-header b i {
    color: #80deea !important;
    margin-right: 8px;
}
#sidebarCollapse {
    background: rgba(255,255,255,0.08) !important;
    border: none !important;
    color: #cbd5e1 !important;
    font-size: 22px !important;
    padding: 6px 12px !important;
    border-radius: 12px !important;
    transition: background 0.2s;
    cursor: pointer;
}
#sidebarCollapse:hover {
    background: rgba(255,255,255,0.2) !important;
    color: #fff !important;
}
@media (min-width: 769px) {
    #sidebarCollapse {
        display: none !important;
    }
}

/* --- Menu items --- */
#sidebar ul.components {
    padding: 12px 8px 20px !important;
    list-style: none;
    margin: 0;
}
#sidebar ul li {
    margin: 2px 0 !important;
}
#sidebar ul li a {
    display: flex !important;
    align-items: center !important;
    gap: 14px !important;
    padding: 10px 16px !important;
    color: #c5e0e8 !important;
    text-decoration: none !important;
    border-radius: 14px !important;
    transition: all 0.25s ease !important;
    font-weight: 500 !important;
    background: transparent !important;
    border-left: 3px solid transparent !important;
    font-size: 0.95rem;
}
#sidebar ul li a i {
    width: 22px !important;
    text-align: center !important;
    font-size: 1.1rem !important;
    color: #80cbd6 !important;
    transition: color 0.2s !important;
}
#sidebar ul li a:hover {
    background: rgba(255, 255, 255, 0.12) !important;
    color: #ffffff !important;
    transform: translateX(6px) scale(1.02) !important;
    border-left-color: #4dd0e1 !important;
    box-shadow: 0 4px 16px rgba(0, 200, 200, 0.15) !important;
}
#sidebar ul li a:hover i {
    color: #4dd0e1 !important;
}
#sidebar ul li.active a,
#sidebar ul li.active > a {
    background: linear-gradient(90deg, rgba(0, 137, 123, 0.4), rgba(38, 166, 154, 0.2)) !important;
    backdrop-filter: blur(4px);
    color: #fff !important;
    font-weight: 600 !important;
    box-shadow: 0 8px 24px rgba(0, 137, 123, 0.2) !important;
    border-left-color: #b2dfdb !important;
}
#sidebar ul li.active a i {
    color: #ffffff !important;
}

/* --- Header seksyen --- */
.menu-header {
    padding: 8px 16px 4px !important;
    margin-top: 18px !important;
    margin-bottom: 2px !important;
}
.menu-header-text {
    font-size: 11px !important;
    letter-spacing: 1.8px !important;
    color: #8fcdd6 !important;
    text-transform: uppercase !important;
    opacity: 0.85 !important;
    font-weight: 600 !important;
}
.tricolor_line {
    height: 2px !important;
    width: 44px !important;
    margin-top: 6px !important;
    background: linear-gradient(90deg, #00897b, #4dd0e1, #b2dfdb) !important;
    border-radius: 4px !important;
}
</style>

<!-- ===== OVERLAY ===== -->
<div id="sidebarOverlay"></div>

<!-- ===== SIDEBAR ===== -->
<nav id="sidebar" class="bg-body-tertiary shadow">
    <div class="sidebar-header">
        <button id="sidebarCollapse" aria-label="Toggle Sidebar">
            <i class="fa-solid fa-bars"></i>
        </button>
        <b><i class="fa-solid fa-envelope-open-text"></i> <?php echo $system_abbr; ?></b>
    </div>
    <div class="px-0">
        <ul class="list-unstyled components">
            <?php if ($this->Identity->isLoggedIn() == NULL): ?>
                <li class="menu-item">
                    <?= $this->Html->link(__('<i class="menu-icon fa-solid fa-right-to-bracket"></i> Sign-in'), ['controller' => 'Users', 'action' => 'login', 'prefix' => false], ['class' => 'menu-link', 'escape' => false]) ?>
                </li>
            <?php endif; ?>

            <?php if ($this->Identity->isLoggedIn()): ?>
                <li class="menu-item <?= $c_name == 'Dashboards' ? 'active' : '' ?>">
                    <?= $this->Html->link(__('<i class="menu-icon fa-solid fa-chart-line"></i> Dashboard'), ['controller' => 'Dashboards', 'action' => 'index', 'prefix' => false], ['class' => 'menu-link', 'escape' => false]) ?>
                </li>

                <li class="menu-header fw-bold text-uppercase mt-4 mb-3">
                    <span class="menu-header-text ps-4">Letter Management</span>
                    <div class="tricolor_line mb-3"></div>
                </li>
                <li class="menu-item <?= $c_name == 'Appointments' ? 'active' : '' ?>">
                    <?= $this->Html->link(__('<i class="menu-icon fa-solid fa-envelope-open-text"></i> Appointment Letters'), ['controller' => 'Appointments', 'action' => 'index', 'prefix' => false], ['class' => 'menu-link', 'escape' => false]) ?>
                </li>
                <li class="menu-item <?= $c_name == 'Lecturers' ? 'active' : '' ?>">
                    <?= $this->Html->link(__('<i class="menu-icon fa-solid fa-chalkboard-user"></i> Lecturers'), ['controller' => 'Lecturers', 'action' => 'index', 'prefix' => false], ['class' => 'menu-link', 'escape' => false]) ?>
                </li>
                <li class="menu-item <?= $c_name == 'Faculties' ? 'active' : '' ?>">
                    <?= $this->Html->link(__('<i class="menu-icon fa-solid fa-building-columns"></i> Faculties'), ['controller' => 'Faculties', 'action' => 'index', 'prefix' => false], ['class' => 'menu-link', 'escape' => false]) ?>
                </li>
                <li class="menu-item <?= $c_name == 'Programs' ? 'active' : '' ?>">
                    <?= $this->Html->link(__('<i class="menu-icon fa-solid fa-layer-group"></i> Programs'), ['controller' => 'Programs', 'action' => 'index', 'prefix' => false], ['class' => 'menu-link', 'escape' => false]) ?>
                </li>
                <li class="menu-item <?= $c_name == 'Projects' ? 'active' : '' ?>">
                    <?= $this->Html->link(__('<i class="menu-icon fa-solid fa-diagram-project"></i> Projects'), ['controller' => 'Projects', 'action' => 'index', 'prefix' => false], ['class' => 'menu-link', 'escape' => false]) ?>
                </li>
                <li class="menu-item <?= $c_name == 'Subjects' ? 'active' : '' ?>">
                    <?= $this->Html->link(__('<i class="menu-icon fa-solid fa-book"></i> Subjects'), ['controller' => 'Subjects', 'action' => 'index', 'prefix' => false], ['class' => 'menu-link', 'escape' => false]) ?>
                </li>

                <li class="menu-header fw-bold text-uppercase mt-4 mb-3">
                    <span class="menu-header-text ps-4">Account</span>
                    <div class="tricolor_line mb-3"></div>
                </li>
                <li class="menu-item <?= $c_name == 'Users' && $a_name == 'profile' ? 'active' : '' ?>">
                    <?= $this->Html->link(__('<i class="menu-icon fa-solid fa-user-tie"></i> Profile'), ['controller' => 'Users', 'action' => 'profile', 'prefix' => false, $this->Identity->get('slug')], ['class' => 'menu-link', 'escape' => false]) ?>
                </li>

                <?php if ($this->Identity->get('user_group_id') == '1'): ?>
                    <li class="menu-header fw-bold text-uppercase mt-4 mb-3">
                        <span class="menu-header-text ps-4">Administrator</span>
                        <div class="tricolor_line mb-3"></div>
                    </li>
                    <li class="menu-item <?= $c_name == 'Settings' && $a_name == 'update' ? 'active' : '' ?>">
                        <?= $this->Html->link(__('<i class="menu-icon fa-solid fa-gear"></i> Site Configuration'), ['prefix' => 'Admin', 'controller' => 'Settings', 'action' => 'update', 'recrud'], ['class' => 'menu-link', 'escape' => false]) ?>
                    </li>
                    <li class="menu-item <?= $c_name == 'Users' && $a_name == 'index' ? 'active' : '' ?>">
                        <?= $this->Html->link(__('<i class="menu-icon fa-solid fa-users-viewfinder"></i> User Management'), ['prefix' => 'Admin', 'controller' => 'Users', 'action' => 'index'], ['class' => 'menu-link', 'escape' => false]) ?>
                    </li>
                    <li class="menu-item <?= $c_name == 'AuditLogs' && $a_name == 'index' ? 'active' : '' ?>">
                        <?= $this->Html->link(__('<i class="menu-icon fa-solid fa-timeline"></i> Audit Trail'), ['prefix' => 'Admin', 'controller' => 'auditLogs', 'action' => 'index'], ['class' => 'menu-link', 'escape' => false]) ?>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const btnInside = document.getElementById('sidebarCollapse');

    function updateBodyPadding() {
        if (window.innerWidth <= 768) {
            document.body.style.paddingLeft = '0';
        } else {
            document.body.style.paddingLeft = '280px';
        }
    }
    updateBodyPadding();

    function toggleSidebar(e) {
        if (e) e.preventDefault();
        sidebar.classList.toggle('active');
        if (overlay) overlay.classList.toggle('active');
    }

    function closeSidebar() {
        sidebar.classList.remove('active');
        if (overlay) overlay.classList.remove('active');
    }

    if (btnInside) btnInside.addEventListener('click', toggleSidebar);
    if (overlay) overlay.addEventListener('click', closeSidebar);

    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
            const isClickInside = sidebar.contains(e.target) || 
                                  (overlay && overlay.contains(e.target));
            if (!isClickInside && sidebar.classList.contains('active')) {
                closeSidebar();
            }
        }
    });

    window.addEventListener('resize', function() {
        updateBodyPadding();
        if (window.innerWidth > 768) {
            if (overlay) overlay.classList.remove('active');
        }
    });

    if (overlay) overlay.classList.remove('active');
});
</script>