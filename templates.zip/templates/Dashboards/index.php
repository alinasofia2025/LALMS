<?php $this->assign('title', $title); ?>

<style>
/* ============================================================
   DASHBOARD DENGAN BACKGROUND PATTERN + GLASS EFFECT + ANIMATED LIGHT
   ============================================================ */

/* ----- DEFAULT: LIGHT MODE ----- */
:root {
    --body-bg-color: #e8f0f8;
    --body-pattern: 
        radial-gradient(circle at 20% 50%, rgba(0, 137, 123, 0.10) 0%, transparent 50%),
        radial-gradient(circle at 80% 20%, rgba(38, 166, 154, 0.08) 0%, transparent 40%),
        radial-gradient(circle at 40% 80%, rgba(77, 208, 225, 0.06) 0%, transparent 50%),
        repeating-linear-gradient(45deg, 
            rgba(0, 0, 0, 0.02) 0px, 
            rgba(0, 0, 0, 0.02) 2px, 
            transparent 2px, 
            transparent 8px
        );
    --card-bg: rgba(255, 255, 255, 0.75);
    --card-border: rgba(0, 137, 123, 0.15);
    --card-shadow: 0 8px 32px rgba(0, 137, 123, 0.08);
    --card-text: #1a2a3a;
    --card-text-light: #1a2a3a;
    --header-bg: linear-gradient(135deg, rgba(0, 137, 123, 0.85), rgba(38, 166, 154, 0.75));
    --badge-approved: #00897b;
    --badge-archived: #6c757d;
    --badge-draft: #ffc107;
    --table-header: rgba(0, 137, 123, 0.7);
    --hover-bg: rgba(0, 137, 123, 0.06);
    --text-muted: #4a6a6a;
    --glass-blur: blur(12px);
    --glass-bg: rgba(255, 255, 255, 0.6);
    --glow-color: rgba(77, 208, 225, 0.3);
    --border-color: rgba(0, 137, 123, 0.1);
    --icon-color: #00897b;
    --stat-color: #00897b;
    --btn-text-color: #fff;
}

/* ----- DARK MODE (melalui data attribute) ----- */
[data-bs-theme="dark"] {
    --body-bg-color: #0a1a1e;
    --body-pattern: 
        radial-gradient(circle at 20% 50%, rgba(0, 137, 123, 0.25) 0%, transparent 50%),
        radial-gradient(circle at 80% 20%, rgba(38, 166, 154, 0.18) 0%, transparent 40%),
        radial-gradient(circle at 40% 80%, rgba(77, 208, 225, 0.12) 0%, transparent 50%),
        repeating-linear-gradient(45deg, 
            rgba(255, 255, 255, 0.02) 0px, 
            rgba(255, 255, 255, 0.02) 2px, 
            transparent 2px, 
            transparent 8px
        );
    --card-bg: rgba(10, 30, 34, 0.85);
    --card-border: rgba(77, 208, 225, 0.15);
    --card-shadow: 0 8px 32px rgba(0, 0, 0, 0.6);
    --card-text: #ffffff;
    --card-text-light: #e0f7fa;
    --header-bg: linear-gradient(135deg, rgba(0, 60, 55, 0.9), rgba(0, 137, 123, 0.8));
    --badge-approved: #26a69a;
    --badge-archived: #78909c;
    --badge-draft: #f9a825;
    --table-header: rgba(0, 60, 55, 0.85);
    --hover-bg: rgba(77, 208, 225, 0.08);
    --text-muted: #a0c4c8;
    --glass-bg: rgba(0, 0, 0, 0.45);
    --glow-color: rgba(77, 208, 225, 0.3);
    --border-color: rgba(77, 208, 225, 0.1);
    --icon-color: #4dd0e1;
    --stat-color: #4dd0e1;
    --btn-text-color: #0a1a1e;
}

/* ----- BODY BACKGROUND ----- */
body {
    background-color: var(--body-bg-color);
    background-image: var(--body-pattern);
    background-attachment: fixed;
    min-height: 100vh;
    color: var(--card-text);
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    transition: background 0.4s ease, color 0.3s ease;
}

/* ----- GLOBAL GLASS EFFECT ----- */
.glass {
    background: var(--glass-bg);
    backdrop-filter: var(--glass-blur);
    -webkit-backdrop-filter: var(--glass-blur);
    border: 1px solid var(--card-border);
    box-shadow: var(--card-shadow);
}

/* ----- DASHBOARD HEADER ----- */
.dashboard-header {
    background: var(--header-bg);
    backdrop-filter: var(--glass-blur);
    -webkit-backdrop-filter: var(--glass-blur);
    color: #fff;
    border-radius: 20px;
    padding: 28px 32px;
    border: 1px solid var(--card-border);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
    position: relative;
    overflow: hidden;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.dashboard-header::after {
    content: '';
    position: absolute;
    top: -50%;
    right: -20%;
    width: 300px;
    height: 300px;
    background: rgba(255, 255, 255, 0.06);
    border-radius: 50%;
    transform: rotate(15deg);
    pointer-events: none;
}
.dashboard-header h1 {
    font-weight: 700;
    letter-spacing: 0.5px;
    text-shadow: 0 2px 10px rgba(0,0,0,0.2);
}
.dashboard-header div {
    opacity: 0.9;
    font-weight: 300;
}

/* Theme toggle button */
.theme-toggle {
    background: rgba(255,255,255,0.15);
    border: 1px solid rgba(255,255,255,0.2);
    color: #fff;
    border-radius: 30px;
    padding: 6px 16px;
    font-size: 0.85rem;
    transition: all 0.3s ease;
    cursor: pointer;
    backdrop-filter: blur(4px);
}
.theme-toggle:hover {
    background: rgba(255,255,255,0.25);
    transform: scale(1.05);
}
.theme-toggle i {
    margin-right: 6px;
}

/* ----- CARDS DASHBOARD (Glass + Animated Light) ----- */
.dashboard-card {
    background: var(--card-bg);
    backdrop-filter: var(--glass-blur);
    -webkit-backdrop-filter: var(--glass-blur);
    border: 1px solid var(--card-border);
    border-radius: 20px;
    transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    box-shadow: var(--card-shadow);
    position: relative;
    overflow: hidden;
    color: var(--card-text);
}

/* ===== ANIMATED LIGHT (BORDER GLOW) ===== */
.dashboard-card::before {
    content: '';
    position: absolute;
    top: -2px;
    left: -2px;
    right: -2px;
    bottom: -2px;
    background: linear-gradient(45deg, 
        #00897b, #26a69a, #4dd0e1, #26a69a, #00897b
    );
    background-size: 300% 300%;
    border-radius: 22px;
    z-index: -1;
    animation: borderGlow 4s ease-in-out infinite;
    opacity: 0;
    transition: opacity 0.4s ease;
}
.dashboard-card:hover::before {
    opacity: 1;
}

@keyframes borderGlow {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* ===== SHIMMER EFFECT (CAHAYA BERGERAK) ===== */
.dashboard-card::after {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 60%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.08),
        rgba(255, 255, 255, 0.18),
        rgba(255, 255, 255, 0.08),
        transparent
    );
    transform: skewX(-25deg);
    transition: left 0.8s ease;
    pointer-events: none;
    z-index: 1;
}
.dashboard-card:hover::after {
    left: 150%;
}

/* Dark mode – shimmer lebih lembut */
[data-bs-theme="dark"] .dashboard-card::after {
    background: linear-gradient(
        90deg,
        transparent,
        rgba(77, 208, 225, 0.05),
        rgba(77, 208, 225, 0.12),
        rgba(77, 208, 225, 0.05),
        transparent
    );
}

/* Hover effect */
.dashboard-card:hover {
    transform: translateY(-8px) scale(1.01);
    box-shadow: 0 16px 48px rgba(0, 137, 123, 0.3);
    border-color: rgba(77, 208, 225, 0.5);
}

.dashboard-card .card-body {
    padding: 24px 20px;
    position: relative;
    z-index: 2;
}

.dashboard-card .text-muted {
    color: var(--text-muted) !important;
    font-weight: 600;
    letter-spacing: 0.3px;
}

.dashboard-card .fs-1 {
    color: var(--stat-color);
    font-weight: 800;
    margin: 6px 0 12px;
    text-shadow: 0 0 20px rgba(77, 208, 225, 0.15);
}
[data-bs-theme="dark"] .dashboard-card .fs-1 {
    text-shadow: 0 0 30px rgba(77, 208, 225, 0.3);
}

.dashboard-icon {
    color: var(--icon-color);
    transition: all 0.4s ease;
    opacity: 0.8;
    filter: drop-shadow(0 0 10px rgba(77, 208, 225, 0.1));
}
[data-bs-theme="dark"] .dashboard-icon {
    filter: drop-shadow(0 0 20px rgba(77, 208, 225, 0.3));
}
.dashboard-card:hover .dashboard-icon {
    transform: scale(1.2) rotate(3deg);
    opacity: 1;
    filter: drop-shadow(0 0 30px rgba(77, 208, 225, 0.5));
}

/* Butang dalam card */
.module-btn {
    margin-top: 8px;
    border-radius: 30px;
    padding: 6px 20px;
    font-weight: 600;
    transition: all 0.3s ease;
    background: linear-gradient(135deg, #00897b, #26a69a);
    border: none;
    color: var(--btn-text-color);
    backdrop-filter: blur(4px);
}
.module-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(0, 137, 123, 0.4);
    color: var(--btn-text-color);
}
[data-bs-theme="dark"] .module-btn {
    color: #0a1a1e;
}
[data-bs-theme="dark"] .module-btn:hover {
    color: #0a1a1e;
}

/* ----- TABLE CARD (Glass) ----- */
.card.shadow-sm.border-0 {
    background: var(--card-bg);
    backdrop-filter: var(--glass-blur);
    -webkit-backdrop-filter: var(--glass-blur);
    border: 1px solid var(--card-border);
    border-radius: 20px;
    overflow: hidden;
    box-shadow: var(--card-shadow);
    transition: all 0.3s ease;
}
.card.shadow-sm.border-0:hover {
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.2);
}

.dashboard-table-header {
    background: var(--table-header) !important;
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    color: #fff !important;
    padding: 16px 24px;
    font-size: 1.1rem;
    border-bottom: 1px solid var(--border-color);
}

.table-teal-header th {
    background: rgba(0, 137, 123, 0.15) !important;
    backdrop-filter: blur(4px);
    -webkit-backdrop-filter: blur(4px);
    color: var(--card-text) !important;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    padding: 12px 16px;
    border-bottom: 1px solid var(--border-color);
}
[data-bs-theme="dark"] .table-teal-header th {
    background: rgba(77, 208, 225, 0.1) !important;
    color: #e0f7fa !important;
}

.table-hover tbody tr {
    transition: all 0.2s ease;
    border-left: 3px solid transparent;
    background: transparent;
}
.table-hover tbody tr:hover {
    background: var(--hover-bg) !important;
    border-left-color: #4dd0e1;
    transform: scale(1.002);
}
.table-hover tbody td {
    padding: 12px 16px;
    color: var(--card-text);
    border-bottom: 1px solid var(--border-color);
}
.table-hover tbody tr:last-child td {
    border-bottom: none;
}
[data-bs-theme="dark"] .table-hover tbody td {
    color: #e0f7fa;
}

/* Badges */
.badge {
    padding: 6px 14px;
    border-radius: 30px;
    font-weight: 500;
}
.badge-teal {
    background: var(--badge-approved);
    color: #fff;
}
.badge-teal-archived {
    background: var(--badge-archived);
    color: #fff;
}
.badge-teal-draft {
    background: var(--badge-draft);
    color: #212529;
}
[data-bs-theme="dark"] .badge-teal-draft {
    color: #0a1a1e;
}

/* Butang View di table */
.btn-outline-teal {
    color: var(--icon-color);
    border-color: var(--icon-color);
    border-radius: 30px;
    padding: 4px 16px;
    font-weight: 500;
    transition: all 0.3s ease;
    background: rgba(0, 137, 123, 0.05);
}
.btn-outline-teal:hover {
    background: #00897b;
    color: #fff;
    transform: translateY(-2px);
    box-shadow: 0 4px 20px rgba(0, 137, 123, 0.3);
}
[data-bs-theme="dark"] .btn-outline-teal {
    background: rgba(77, 208, 225, 0.08);
}
[data-bs-theme="dark"] .btn-outline-teal:hover {
    background: #4dd0e1;
    color: #0a1a1e;
    box-shadow: 0 4px 20px rgba(77, 208, 225, 0.4);
}

/* ----- RESPONSIF ----- */
@media (max-width: 768px) {
    .dashboard-header {
        padding: 20px;
        border-radius: 16px;
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
    }
    .dashboard-header h1 {
        font-size: 1.3rem;
    }
    .dashboard-card .fs-1 {
        font-size: 2rem;
    }
}
</style>

<!-- ===== HEADER ===== -->
<div class="dashboard-header mb-4 shadow">
    <div>
        <h1 class="h3 mb-2">
            <i class="fa-solid fa-chart-line me-2"></i>
            Lecturer Appointment Letter Management System
        </h1>
        <div>
Manage faculties, programmes, lecturers, subjects and generate appointment letters.        </div>
    </div>
    <button class="theme-toggle" id="themeToggle" title="Toggle Dark/Light Mode">
        <i class="fa-solid fa-moon"></i> <span id="themeLabel">Dark</span>
    </button>
</div>

<!-- ===== CARDS ===== -->
<div class="row g-4 mb-4">
    <?php
    $cards = [
    ['Faculty', $faculties, 'Faculties', 'fa-building-columns'],
    ['Program', $programs, 'Programs', 'fa-layer-group'],
    ['Lecturer', $lecturers, 'Lecturers', 'fa-chalkboard-user'],
    ['Subject', $subjects, 'Subjects', 'fa-book'],
    ['Appointment Letter', $appointments, 'Appointments', 'fa-envelope-open-text'],
];
    ?>

    <?php foreach ($cards as $card): ?>
        <div class="col-md-4">
            <div class="card dashboard-card shadow-sm border-0 h-100">
                <div class="card-body d-flex justify-content-between align-items-start">
                    <div>
                        <div class="text-muted fw-semibold text-uppercase small">
                            <?= h($card[0]) ?>
                        </div>
                        <div class="fs-1 fw-bold">
                            <?= h($card[1]) ?>
                        </div>
                        <?= $this->Html->link(
                            'Open Module →',
                            ['controller' => $card[2], 'action' => 'index'],
                            ['class' => 'btn module-btn btn-sm']
                        ) ?>
                    </div>
                    <i class="fa-solid <?= h($card[3]) ?> fa-3x dashboard-icon"></i>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<!-- ===== LATEST APPOINTMENTS TABLE ===== -->
<div class="card shadow-sm border-0">
    <div class="card-header dashboard-table-header fw-bold">
        <i class="fa-solid fa-envelope-open-text me-2"></i>
        Latest Appointment Letters
    </div>

    <div class="card-body table-responsive p-0">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-teal-header">
                <tr>
                    <th>Ref No</th>
                    <th>Title</th>
                    <th>Lecturer</th>
                    <th>Faculty</th>
                    <th>Subject</th>
                    <th>Status</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($latestAppointments as $appointment): ?>
                    <tr>
                        <td><span class="fw-semibold"><?= h($appointment->letter_ref_no) ?></span></td>
                        <td><?= h($appointment->appointment_title) ?></td>
                        <td><?= h($appointment->lecturer->name ?? '-') ?></td>
                        <td><?= h($appointment->faculty->code ?? '-') ?></td>
                        <td><?= h($appointment->subject->code ?? '-') ?></td>
                        <td>
                            <?php if ($appointment->status == 1): ?>
                                <span class="badge badge-teal"><i class="fa-regular fa-circle-check me-1"></i> Approved</span>
                            <?php elseif ($appointment->status == 2): ?>
                                <span class="badge badge-teal-archived"><i class="fa-regular fa-folder me-1"></i> Archived</span>
                            <?php else: ?>
                                <span class="badge badge-teal-draft"><i class="fa-regular fa-pen-to-square me-1"></i> Draft</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <?= $this->Html->link(
                                'View →',
                                ['controller' => 'Appointments', 'action' => 'view', $appointment->id],
                                ['class' => 'btn btn-sm btn-outline-teal']
                            ) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <?php if ($latestAppointments->count() === 0): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4" style="color:var(--text-muted);">
                            <i class="fa-regular fa-inbox fa-2x d-block mb-2"></i>
                            No appointment letters yet.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ===== JAVASCRIPT THEME TOGGLE ===== -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const toggleBtn = document.getElementById('themeToggle');
    const themeLabel = document.getElementById('themeLabel');
    const htmlElement = document.documentElement;

    // Check saved theme or system preference
    let currentTheme = localStorage.getItem('theme') || 
                       (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');

    function setTheme(theme) {
        htmlElement.setAttribute('data-bs-theme', theme);
        localStorage.setItem('theme', theme);
        currentTheme = theme;

        // Update button icon and label
        if (theme === 'dark') {
            toggleBtn.innerHTML = '<i class="fa-solid fa-sun"></i> <span id="themeLabel">Light</span>';
        } else {
            toggleBtn.innerHTML = '<i class="fa-solid fa-moon"></i> <span id="themeLabel">Dark</span>';
        }
    }

    // Initial apply
    setTheme(currentTheme);

    // Toggle on click
    toggleBtn.addEventListener('click', function() {
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        setTheme(newTheme);
    });

    // Listen for system theme changes (only if user hasn't manually set)
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function(e) {
        if (!localStorage.getItem('theme')) {
            setTheme(e.matches ? 'dark' : 'light');
        }
    });
});
</script>